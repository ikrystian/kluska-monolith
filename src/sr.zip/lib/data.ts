// This file is no longer in use, data is now fetched from Firebase.
// You can delete this file if you want.
export {};

    