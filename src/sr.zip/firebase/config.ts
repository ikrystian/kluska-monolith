export const firebaseConfig = {
  "projectId": "studio-3939394625-271f8",
  "appId": "1:248944256661:web:38150628f308a87eebdd9c",
  "apiKey": "AIzaSyBuC2aKRz-WZEjPQTW9QlBudjwCxt6qt18",
  "authDomain": "studio-3939394625-271f8.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "248944256661"
};
